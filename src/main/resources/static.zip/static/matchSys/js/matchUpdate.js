var vm = new Vue({
	el:"#result",
	data:{
		matchId:0,
		refereeId:0,
		areaBookId:0,
		title:"",
		message:"",
		refereeList:[],
		areaList:[]
	},
	methods:{
		confirm:function(){
			if (confirm("您确定提交信息吗？") == true){
				$.ajax({
					type: "PUT",
					url: ("http://127.0.0.1:8080/matchInfo?matchId="+this.matchId+"&refereeId="+this.refereeId+"&areaBookId="+this.areaBookId+"&title="+this.title+"&message="+this.message),
					dataType: "json",
					contentType:"application/json;charset=UTF-8",
					success: function(data){
						console.log(data);
						alert("修改成功");
						window.location.href = "matchList.html";
					}
				});
			}
		}
	},
	created:function(){
		var id = GetQueryString("id");
		$.ajax({
            type:"get",
            url: ("http://127.0.0.1:8080/matchInfo/"+id),
            contentType:'application/json;charset=UTF-8',
            dataType:"json",
            async:true,
            success:function(data){
            	if(data.code == 200){
            		vm.$data.matchId = data.data.matchId;
					vm.$data.refereeId = data.data.refereeId;
					vm.$data.areaBookId = data.data.areaBookId;
					vm.$data.title = data.data.title;
					vm.$data.message = data.data.message;
				}
            }
        });
        $.ajax({
            type:"get",
            url: "http://127.0.0.1:8080/refereeInfo/list",
            contentType:'application/json;charset=UTF-8',
            dataType:"json",
            async:true,
            success:function(data){
            	if(data.code == 200){
					list = [];
					for(i = 0 ; i < data.data.length ; i++){
						var referee = {
							refereeId:data.data[i].refereeId,
							name:data.data[i].name
						}
						list.push(referee);
					};
					vm.$data.refereeList = list;
				}
            }
        });
        $.ajax({
            type:"get",
            url: "http://127.0.0.1:8080/areaInfo/list",
            contentType:'application/json;charset=UTF-8',
            dataType:"json",
            async:true,
            success:function(data){
            	if(data.code == 200){
					list = [];
					for(i = 0 ; i < data.data.length ; i++){
						var place = {
							areaId:data.data[i].areaId,
							name:data.data[i].name
						}
						list.push(place);
					};
					vm.$data.areaList = list;
				}
            }
        });
        function GetQueryString(name){
		    var reg = new RegExp("(^|&)"+ name +"=([^&]*)(&|$)");
			var r = window.location.search.substr(1).match(reg);
			if(r!=null)
				return  unescape(r[2]); 
			return null;
		}
	}
})