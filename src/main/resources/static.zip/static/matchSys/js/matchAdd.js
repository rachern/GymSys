var vm = new Vue({
	el:"#result",
	data:{
		refereeList:[],
		areaList:[],
		refereeId:0,
		areaId:0,
		message:"",
		title:""
	},
	methods:{
		confirm:function(){
			if (confirm("您确定提交信息吗？") == true){
				$.ajax({
					type: "POST",
					url: ("http://127.0.0.1:8080/matchInfo?refereeId="+this.refereeId+"&areaBookId="+this.areaId+"&title="+this.title+"&message="+this.message),
					dataType: "json",
					contentType:"application/json;charset=UTF-8",
					success: function(data){
						console.log(data);
						alert("添加成功");
						window.location.href = "matchList.html";
					}
				});
			}
		}
	},
	created:function(){
		$.ajax({
            type:"get",
            url: "http://127.0.0.1:8080/refereeInfo/list",
            contentType:'application/json;charset=UTF-8',
            dataType:"json",
            async:true,
            success:function(data){
            	if(data.code == 200){
					list = [];
					for(i = 0 ; i < data.data.length ; i++){
						var referee = {
							refereeId:data.data[i].refereeId,
							name:data.data[i].name
						}
						list.push(referee);
					};
					vm.$data.refereeList = list;
				}
            }
        });
        $.ajax({
            type:"get",
            url: "http://127.0.0.1:8080/areaInfo/list",
            contentType:'application/json;charset=UTF-8',
            dataType:"json",
            async:true,
            success:function(data){
            	if(data.code == 200){
					list = [];
					for(i = 0 ; i < data.data.length ; i++){
						var place = {
							areaId:data.data[i].areaId,
							name:data.data[i].name
						}
						list.push(place);
					};
					vm.$data.areaList = list;
				}
            }
        });
	}
})